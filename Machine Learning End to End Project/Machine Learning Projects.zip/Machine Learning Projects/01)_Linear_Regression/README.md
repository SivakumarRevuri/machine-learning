# Linear Regression
**Life Expectancy Using Linear Regression**

The aim of this project is to understand the working of Linear Regression and calculate the life expectancy of a human in any country using the same Linear Regression Algorithm.

https://github.com/maanasvi999/LinearRegression
