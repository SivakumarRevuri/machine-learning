# Random Forest Classifier
The aim of this project is to understand Random Forest Classification Algorithm.
Using the algorithm to get the best suitable crop for a given set of soil parameters and surrounding settings parameters.
Hence, a **Crop Recommendation System** Project using Random Forest Classifier.

We also compare the accuracy of models developed using Decision Tree and Random Forest Classifier.

https://github.com/maanasvi999/RandomForestClassifier
